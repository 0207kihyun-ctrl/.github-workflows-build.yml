@echo off
rem Gradle wrapper Windows script
gradle %*
