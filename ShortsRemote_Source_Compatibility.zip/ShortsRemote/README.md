# Shorts Remote (쇼츠 리모컨)
> 삼성 갤럭시 워치 5(40mm) 전용 YouTube Shorts 블루투스 HID 리모컨 & 마우스 터치패드 Wear OS 앱

본 프로젝트는 WearMouse와 완전히 독립된 독립형(Standalone) Wear OS 앱입니다.
아이폰에 별도 앱을 설치하지 않고 표준 블루투스 HID 프로필로 직접 연결됩니다.

## 📌 주요 화면 구성
1. 메인 화면 (세로 배치 3버튼)
   - ▲ 다음 쇼츠: HID Down Arrow (0x51)
   - ♥ 좋아요 (가운데): HID 'L' (0x0F)
   - ▼ 이전 쇼츠: HID Up Arrow (0x52)
2. 터치패드 화면
   - 화면 드래그: 아이폰 마우스 커서 이동
   - 탭: 마우스 좌클릭 (AssistiveTouch Click)
   - 손목 모션: 자이로 센서 실시간 커서 제어
   - 뒤로가기 버튼

## 🔨 APK 빌드 및 설치
1. Android Studio에서 프로젝트 열기
2. Build > Build Bundle(s) / APK(s) > Build APK(s) 실행
3. 워치에서 Wi-Fi 무선 디버깅 활성화 후:
   adb connect <워치IP>:<포트>
   adb install app-debug.apk

## Wear OS 호환성 설정 점검 (수정본)
- minSdk: 28 (Bluetooth HID Device API가 도입된 Android 9/API 28 이상)
- targetSdk: 34 (기존 값 유지)
- compileSdk: 34 (기존 값 유지)
- ABI: armeabi-v7a, arm64-v8a (기존 값 유지)
- Wear OS 전용 기능 선언을 required=true로 명시

참고: minSdk를 낮춘 것은 설치 가능한 Android API 하한을 넓히는 설정입니다. 실제 기기에서 Bluetooth HID Device 프로필 사용 가능 여부는 제조사 펌웨어/시스템 구현에 따라 달라질 수 있습니다. Galaxy Watch 5 실기기 설치와 HID 페어링은 별도 테스트가 필요합니다. 이 ZIP은 소스 수정본이며 APK를 빌드한 파일은 아닙니다.
