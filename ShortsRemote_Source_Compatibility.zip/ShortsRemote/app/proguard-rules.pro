# Keep Bluetooth HID framework callback implementations and descriptor-related classes.
-keep class com.shortsremote.app.bluetooth.** { *; }
-keep class com.shortsremote.app.sensor.** { *; }

# Keep Compose-generated and Kotlin metadata attributes.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
