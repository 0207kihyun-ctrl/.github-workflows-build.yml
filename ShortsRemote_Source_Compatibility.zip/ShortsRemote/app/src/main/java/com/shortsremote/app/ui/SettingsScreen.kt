package com.shortsremote.app.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.*
import com.shortsremote.app.bluetooth.BluetoothHidManager
import com.shortsremote.app.sensor.WristMotionDetector
import com.shortsremote.app.ui.theme.*

@Composable
fun SettingsScreen(
    hidManager: BluetoothHidManager,
    wristMotionDetector: WristMotionDetector,
    onNavigateBack: () -> Unit
) {
    val view = LocalView.current
    var sensitivity by remember { mutableStateOf(wristMotionDetector.sensitivity) }
    val lastLog by hidManager.lastLog.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, start = 10.dp, end = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceElevated)
                        .clickable {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            onNavigateBack()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "뒤로가기",
                        tint = TextWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Text(
                    text = "설정",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.size(32.dp))
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "손목 모션 감도: ${sensitivity.toInt()}",
                    fontSize = 11.sp,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            if (sensitivity > 10f) {
                                sensitivity -= 5f
                                wristMotionDetector.sensitivity = sensitivity
                                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            }
                        },
                        modifier = Modifier.size(36.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = DarkSurfaceElevated)
                    ) {
                        Text("-", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (sensitivity < 60f) {
                                sensitivity += 5f
                                wristMotionDetector.sensitivity = sensitivity
                                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            }
                        },
                        modifier = Modifier.size(36.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = DarkSurfaceElevated)
                    ) {
                        Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                        hidManager.initialize()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(38.dp),
                    colors = ButtonDefaults.buttonColors(backgroundColor = DarkSurfaceElevated)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = AccentBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("블루투스 재등록", fontSize = 11.sp)
                    }
                }
            }

            Text(
                text = lastLog,
                fontSize = 9.sp,
                color = TextMuted,
                maxLines = 1,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }
    }
}