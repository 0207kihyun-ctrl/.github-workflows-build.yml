package com.shortsremote.app.bluetooth

object HidPayloads {
    const val KEY_DOWN_ARROW: Byte = 0x51   // Next Short
    const val KEY_UP_ARROW: Byte = 0x52     // Prev Short
    const val KEY_PAGE_DOWN: Byte = 0x4E
    const val KEY_PAGE_UP: Byte = 0x4B
    const val KEY_L: Byte = 0x0F            // Like key
    const val KEY_SPACE: Byte = 0x2C        // Play / Pause

    const val MOUSE_BUTTON_NONE: Byte = 0x00
    const val MOUSE_BUTTON_LEFT: Byte = 0x01
    const val MOUSE_BUTTON_RIGHT: Byte = 0x02

    fun mouseReport(buttons: Byte = MOUSE_BUTTON_NONE, dx: Int = 0, dy: Int = 0, wheel: Int = 0): ByteArray {
        val clampedDx = dx.coerceIn(-127, 127).toByte()
        val clampedDy = dy.coerceIn(-127, 127).toByte()
        val clampedWheel = wheel.coerceIn(-127, 127).toByte()
        return byteArrayOf(buttons, clampedDx, clampedDy, clampedWheel)
    }

    fun keyboardReport(modifier: Byte = 0x00, keyCode: Byte = 0x00): ByteArray {
        return byteArrayOf(modifier, 0x00.toByte(), keyCode, 0x00, 0x00, 0x00, 0x00, 0x00)
    }

    fun keyboardRelease(): ByteArray = ByteArray(8)
}