package com.shortsremote.app.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/**
 * Detects wrist movements on Samsung Galaxy Watch 5 using Gyroscope & Accelerometer.
 * Converts angular wrist motion into relative (dx, dy) mouse cursor coordinates.
 */
class WristMotionDetector(
    private val context: Context,
    private val onMotionDelta: (dx: Int, dy: Int) -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroscope: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

    var sensitivity: Float = 28.0f
    var deadband: Float = 0.08f
    var invertX: Boolean = false
    var invertY: Boolean = false

    private var smoothedDx = 0f
    private var smoothedDy = 0f
    private val filterAlpha = 0.4f

    fun start(): Boolean {
        if (gyroscope == null) return false
        val registered = sensorManager.registerListener(
            this,
            gyroscope,
            SensorManager.SENSOR_DELAY_GAME
        )
        _isActive.value = registered
        return registered
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        _isActive.value = false
        smoothedDx = 0f
        smoothedDy = 0f
    }

    fun toggle(): Boolean {
        return if (_isActive.value) {
            stop()
            false
        } else {
            start()
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (!_isActive.value || event == null) return

        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            val rawPitch = event.values[0]
            val rawRoll = event.values[1]

            val filteredX = if (abs(rawRoll) > deadband) rawRoll else 0f
            val filteredY = if (abs(rawPitch) > deadband) rawPitch else 0f

            if (filteredX == 0f && filteredY == 0f) {
                smoothedDx = 0f
                smoothedDy = 0f
                return
            }

            smoothedDx = filterAlpha * filteredX + (1 - filterAlpha) * smoothedDx
            smoothedDy = filterAlpha * filteredY + (1 - filterAlpha) * smoothedDy

            val targetDx = (smoothedDx * sensitivity * (if (invertX) -1 else 1)).toInt()
            val targetDy = (smoothedDy * sensitivity * (if (invertY) 1 else -1)).toInt()

            if (targetDx != 0 || targetDy != 0) {
                onMotionDelta(targetDx, targetDy)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}