package com.shortsremote.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

/**
 * Manages Bluetooth HID Profile on Wear OS (Samsung Galaxy Watch 5).
 * Enables the watch to advertise and connect directly to an iPhone as a standard HID Combo device (Mouse + Keyboard).
 * No iPhone companion app required.
 */
class BluetoothHidManager(private val context: Context) {

    companion object {
        private const val TAG = "ShortsRemote_HID"
        private const val APP_NAME = "Shorts Remote"
        private const val APP_DESCRIPTION = "Galaxy Watch 5 Shorts Remote & Touchpad"
        private const val APP_PROVIDER = "ShortsRemote"
    }

    sealed class ConnectionState {
        object Initializing : ConnectionState()
        object BluetoothDisabled : ConnectionState()
        object ProfileConnecting : ConnectionState()
        object ProfileReady : ConnectionState()
        object AppRegistered : ConnectionState()
        data class Connected(val deviceName: String, val address: String) : ConnectionState()
        object Disconnected : ConnectionState()
        data class Error(val message: String) : ConnectionState()
    }

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var hidDevice: BluetoothHidDevice? = null
    private var connectedDevice: BluetoothDevice? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private val executor = Executors.newSingleThreadExecutor()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Initializing)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _lastLog = MutableStateFlow<String>("초기화 대기 중")
    val lastLog: StateFlow<String> = _lastLog.asStateFlow()

    private val hidDeviceCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            super.onAppStatusChanged(pluggedDevice, registered)
            Log.d(TAG, "onAppStatusChanged: registered=$registered, device=${pluggedDevice?.name}")
            if (registered) {
                _connectionState.value = ConnectionState.AppRegistered
                _lastLog.value = "HID 앱 등록 완료. iPhone 블루투스 목록에서 검색 가능"
                pluggedDevice?.let { dev ->
                    handleDeviceConnected(dev)
                }
            } else {
                _connectionState.value = ConnectionState.Disconnected
                _lastLog.value = "HID 앱 등록 해제됨"
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            super.onConnectionStateChanged(device, state)
            Log.d(TAG, "onConnectionStateChanged: state=$state, device=${device?.address}")
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    device?.let { handleDeviceConnected(it) }
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    connectedDevice = null
                    _connectionState.value = ConnectionState.Disconnected
                    _lastLog.value = "iPhone 연결 끊김"
                }
                BluetoothProfile.STATE_CONNECTING -> {
                    _connectionState.value = ConnectionState.ProfileConnecting
                    _lastLog.value = "iPhone 연결 중…"
                }
            }
        }
    }

    private val profileServiceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                Log.d(TAG, "Bluetooth HID Device Profile 서비스 연결됨")
                hidDevice = proxy as? BluetoothHidDevice
                _connectionState.value = ConnectionState.ProfileReady
                _lastLog.value = "HID 서비스 준비 완료. 앱 등록 진행"
                registerHidApp()
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                Log.d(TAG, "Bluetooth HID Device Profile 서비스 해제됨")
                hidDevice = null
                _connectionState.value = ConnectionState.Disconnected
                _lastLog.value = "HID 서비스 연결 끊김"
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun initialize() {
        if (bluetoothAdapter == null) {
            _connectionState.value = ConnectionState.Error("블루투스를 지원하지 않는 기기입니다.")
            return
        }

        if (!bluetoothAdapter.isEnabled) {
            _connectionState.value = ConnectionState.BluetoothDisabled
            _lastLog.value = "블루투스가 꺼져 있습니다. 워치 설정에서 켜주세요."
            return
        }

        _connectionState.value = ConnectionState.ProfileConnecting
        val success = bluetoothAdapter.getProfileProxy(
            context,
            profileServiceListener,
            BluetoothProfile.HID_DEVICE
        )

        if (!success) {
            _connectionState.value = ConnectionState.Error("HID 프로필 프록시 획득 실패")
        }
    }

    @SuppressLint("MissingPermission")
    private fun registerHidApp() {
        val proxy = hidDevice ?: return

        val sdp = BluetoothHidDeviceAppSdpSettings(
            APP_NAME,
            APP_DESCRIPTION,
            APP_PROVIDER,
            BluetoothHidDevice.SUBCLASS1_COMBO,
            HidReportDescriptor.DESCRIPTOR
        )

        val qos = BluetoothHidDeviceAppQosSettings(
            BluetoothHidDeviceAppQosSettings.SERVICE_BEST_EFFORT,
            800,
            9,
            0,
            11250,
            BluetoothHidDeviceAppQosSettings.MAX
        )

        try {
            val registered = proxy.registerApp(sdp, null, qos, executor, hidDeviceCallback)
            if (registered) {
                _lastLog.value = "HID 프로필 등록 요청 성공"
            } else {
                _connectionState.value = ConnectionState.Error("HID 프로필 등록 실패 (이미 등록되었거나 권한 부족)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "registerApp exception", e)
            _connectionState.value = ConnectionState.Error("등록 오류: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun handleDeviceConnected(device: BluetoothDevice) {
        connectedDevice = device
        val name = device.name ?: "iPhone"
        _connectionState.value = ConnectionState.Connected(name, device.address)
        _lastLog.value = "iPhone($name) 연결 성공!"
    }

    @SuppressLint("MissingPermission")
    fun sendMouseMove(dx: Int, dy: Int, buttons: Byte = HidPayloads.MOUSE_BUTTON_NONE) {
        val proxy = hidDevice ?: return
        val target = connectedDevice ?: return

        val report = HidPayloads.mouseReport(buttons = buttons, dx = dx, dy = dy, wheel = 0)
        proxy.sendReport(target, HidReportDescriptor.REPORT_ID_MOUSE.toInt(), report)
    }

    @SuppressLint("MissingPermission")
    fun sendMouseClick() {
        val proxy = hidDevice ?: return
        val target = connectedDevice ?: return

        scope.launch {
            val downReport = HidPayloads.mouseReport(buttons = HidPayloads.MOUSE_BUTTON_LEFT, dx = 0, dy = 0)
            proxy.sendReport(target, HidReportDescriptor.REPORT_ID_MOUSE.toInt(), downReport)

            delay(35)

            val upReport = HidPayloads.mouseReport(buttons = HidPayloads.MOUSE_BUTTON_NONE, dx = 0, dy = 0)
            proxy.sendReport(target, HidReportDescriptor.REPORT_ID_MOUSE.toInt(), upReport)
            _lastLog.value = "마우스 클릭 전송 (Left Click)"
        }
    }

    @SuppressLint("MissingPermission")
    fun sendMouseWheel(wheelDelta: Int) {
        val proxy = hidDevice ?: return
        val target = connectedDevice ?: return

        val report = HidPayloads.mouseReport(buttons = HidPayloads.MOUSE_BUTTON_NONE, dx = 0, dy = 0, wheel = wheelDelta)
        proxy.sendReport(target, HidReportDescriptor.REPORT_ID_MOUSE.toInt(), report)
    }

    @SuppressLint("MissingPermission")
    fun sendKeyPress(keyCode: Byte) {
        val proxy = hidDevice ?: return
        val target = connectedDevice ?: return

        scope.launch {
            proxy.sendReport(
                target,
                HidReportDescriptor.REPORT_ID_KEYBOARD.toInt(),
                HidPayloads.keyboardReport(keyCode = keyCode)
            )

            delay(40)

            proxy.sendReport(
                target,
                HidReportDescriptor.REPORT_ID_KEYBOARD.toInt(),
                HidPayloads.keyboardRelease()
            )
        }
    }

    fun sendNextShort() {
        sendKeyPress(HidPayloads.KEY_DOWN_ARROW)
        _lastLog.value = "다음 쇼츠 전송 (KEY_DOWN_ARROW 0x51)"
    }

    fun sendPrevShort() {
        sendKeyPress(HidPayloads.KEY_UP_ARROW)
        _lastLog.value = "이전 쇼츠 전송 (KEY_UP_ARROW 0x52)"
    }

    fun sendLikeShort() {
        sendKeyPress(HidPayloads.KEY_L)
        _lastLog.value = "좋아요 전송 (KEY_L 0x0F)"
    }

    @SuppressLint("MissingPermission")
    fun release() {
        try {
            hidDevice?.let { proxy ->
                proxy.unregisterApp()
                bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, proxy)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing HID proxy", e)
        }
        hidDevice = null
        connectedDevice = null
    }
}