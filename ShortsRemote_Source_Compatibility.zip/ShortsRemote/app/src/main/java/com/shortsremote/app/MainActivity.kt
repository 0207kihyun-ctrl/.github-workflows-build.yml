package com.shortsremote.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.shortsremote.app.bluetooth.BluetoothHidManager
import com.shortsremote.app.sensor.WristMotionDetector
import com.shortsremote.app.ui.MainShortsScreen
import com.shortsremote.app.ui.SettingsScreen
import com.shortsremote.app.ui.TouchpadScreen
import com.shortsremote.app.ui.theme.ShortsRemoteTheme

enum class ScreenState {
    MAIN,
    TOUCHPAD,
    SETTINGS
}

/**
 * Main Activity for Shorts Remote Wear OS App (Samsung Galaxy Watch 5 - 40mm).
 * Completely standalone app connecting directly to iPhone via Bluetooth HID without a companion app.
 */
class MainActivity : ComponentActivity() {

    private lateinit var hidManager: BluetoothHidManager
    private lateinit var wristMotionDetector: WristMotionDetector

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.all { it.value }
        if (allGranted) {
            hidManager.initialize()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on during remote usage on Galaxy Watch 5
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Initialize Bluetooth HID Manager
        hidManager = BluetoothHidManager(applicationContext)

        // Initialize Wrist Motion Sensor Detector
        wristMotionDetector = WristMotionDetector(applicationContext) { dx, dy ->
            hidManager.sendMouseMove(dx, dy)
        }

        checkAndRequestPermissions()

        setContent {
            ShortsRemoteTheme {
                var currentScreen by remember { mutableStateOf(ScreenState.MAIN) }

                Crossfade(targetState = currentScreen, label = "screenTransition") { screen ->
                    when (screen) {
                        ScreenState.MAIN -> {
                            MainShortsScreen(
                                hidManager = hidManager,
                                onNavigateToTouchpad = { currentScreen = ScreenState.TOUCHPAD },
                                onNavigateToSettings = { currentScreen = ScreenState.SETTINGS }
                            )
                        }
                        ScreenState.TOUCHPAD -> {
                            TouchpadScreen(
                                hidManager = hidManager,
                                wristMotionDetector = wristMotionDetector,
                                onNavigateBack = { currentScreen = ScreenState.MAIN }
                            )
                        }
                        ScreenState.SETTINGS -> {
                            SettingsScreen(
                                hidManager = hidManager,
                                wristMotionDetector = wristMotionDetector,
                                onNavigateBack = { currentScreen = ScreenState.MAIN }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val requiredPermissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requiredPermissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) {
                requiredPermissions.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                requiredPermissions.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        }

        if (requiredPermissions.isEmpty()) {
            hidManager.initialize()
        } else {
            permissionLauncher.launch(requiredPermissions.toTypedArray())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        wristMotionDetector.stop()
        hidManager.release()
    }
}