package com.shortsremote.app.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.*
import com.shortsremote.app.bluetooth.BluetoothHidManager
import com.shortsremote.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Main YouTube Shorts Remote Screen for Samsung Galaxy Watch 5 (40mm - 396x396 circular display).
 * Requirements:
 * Vertically stacked 3 buttons:
 * 1. ▲ 다음 쇼츠 (Next Shorts)
 * 2. ♥ 좋아요 (Like) - In the middle
 * 3. ▼ 이전 쇼츠 (Previous Shorts)
 */
@Composable
fun MainShortsScreen(
    hidManager: BluetoothHidManager,
    onNavigateToTouchpad: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val connectionState by hidManager.connectionState.collectAsState()
    val lastLog by hidManager.lastLog.collectAsState()
    val view = LocalView.current
    val coroutineScope = rememberCoroutineScope()

    var heartPressed by remember { mutableStateOf(false) }
    var heartActiveCount by remember { mutableStateOf(0) }
    val heartScale by animateFloatAsState(
        targetValue = if (heartPressed) 1.25f else 1.0f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 600f),
        label = "heartScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header: Connection status & Quick Nav to Touchpad
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, start = 24.dp, end = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val isConnected = connectionState is BluetoothHidManager.ConnectionState.Connected
                val statusText = when (connectionState) {
                    is BluetoothHidManager.ConnectionState.Connected -> "iPhone 연결됨"
                    is BluetoothHidManager.ConnectionState.AppRegistered -> "페어링 대기"
                    is BluetoothHidManager.ConnectionState.ProfileConnecting -> "연결 중…"
                    is BluetoothHidManager.ConnectionState.BluetoothDisabled -> "BT 꺼짐"
                    else -> "미연결"
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isConnected) Color(0x2210B981) else Color(0x22EF4444))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isConnected) SuccessGreen else Color(0xFFEF4444))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = statusText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isConnected) SuccessGreen else TextMuted
                    )
                }

                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceElevated)
                        .clickable {
                            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                            onNavigateToTouchpad()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mouse,
                        contentDescription = "터치패드로 이동",
                        tint = AccentBlue,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // ========================================================
            // REQUIRED 3 VERTICALLY STACKED BUTTONS (Like in Middle)
            // ========================================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically)
            ) {
                // 1. ▲ 다음 쇼츠 (Next Shorts)
                Button(
                    onClick = {
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        hidManager.sendNextShort()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.86f)
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = DarkSurfaceElevated,
                        contentColor = TextWhite
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "다음 쇼츠",
                            tint = AccentBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "다음 쇼츠",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                // 2. ♥ 좋아요 (Like) - In the middle
                Button(
                    onClick = {
                        view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                        coroutineScope.launch {
                            heartPressed = true
                            heartActiveCount++
                            hidManager.sendLikeShort()
                            delay(180)
                            heartPressed = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(54.dp)
                        .scale(heartScale),
                    shape = RoundedCornerShape(27.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = HeartPink,
                        contentColor = Color.White
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "좋아요",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (heartActiveCount > 0) "좋아요 ($heartActiveCount)" else "좋아요",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }
                }

                // 3. ▼ 이전 쇼츠 (Previous Shorts)
                Button(
                    onClick = {
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        hidManager.sendPrevShort()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.86f)
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = DarkSurfaceElevated,
                        contentColor = TextWhite
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = "이전 쇼츠",
                            tint = AccentBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "이전 쇼츠",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Footer info
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "터치패드 이동 →",
                    fontSize = 11.sp,
                    color = AccentBlue,
                    modifier = Modifier.clickable { onNavigateToTouchpad() }
                )
            }
        }
    }
}