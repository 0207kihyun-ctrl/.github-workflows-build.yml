package com.shortsremote.app.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.Icon
import androidx.wear.compose.material.Text
import com.shortsremote.app.bluetooth.BluetoothHidManager
import com.shortsremote.app.sensor.WristMotionDetector
import com.shortsremote.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Dedicated Touchpad Screen for Galaxy Watch 5 (40mm).
 * Requirements:
 * 1. Finger movement controls iPhone mouse cursor
 * 2. Tapping performs mouse click (AssistiveTouch Click)
 * 3. Wrist movement controls cursor via motion sensors (Gyroscope / Accelerometer)
 * 4. Back button to return to Main Screen
 */
@Composable
fun TouchpadScreen(
    hidManager: BluetoothHidManager,
    wristMotionDetector: WristMotionDetector,
    onNavigateBack: () -> Unit
) {
    val isWristMotionActive by wristMotionDetector.isActive.collectAsState()
    val view = LocalView.current
    val coroutineScope = rememberCoroutineScope()

    var lastTouchOffset by remember { mutableStateOf<Offset?>(null) }
    var showTapEffect by remember { mutableStateOf(false) }
    var tapPosition by remember { mutableStateOf(Offset.Zero) }

    val touchSensitivity = 1.6f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                        tapPosition = offset
                        showTapEffect = true
                        hidManager.sendMouseClick()
                        coroutineScope.launch {
                            delay(150)
                            showTapEffect = false
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        lastTouchOffset = offset
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val dx = (dragAmount.x * touchSensitivity).toInt()
                        val dy = (dragAmount.y * touchSensitivity).toInt()

                        if (dx != 0 || dy != 0) {
                            hidManager.sendMouseMove(dx, dy)
                        }
                    },
                    onDragEnd = {
                        lastTouchOffset = null
                    },
                    onDragCancel = {
                        lastTouchOffset = null
                    }
                )
            }
    ) {
        Box(
            modifier = Modifier
                .size(160.dp)
                .align(Alignment.Center)
                .clip(CircleShape)
                .background(Color(0x0AFFFFFF))
        )

        if (showTapEffect) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(Color(0x66FF0055))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Back Button & Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, start = 12.dp, end = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back Button
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceElevated)
                        .clickable {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            onNavigateBack()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "뒤로가기",
                        tint = TextWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = "터치패드",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.size(34.dp))
            }

            // Center Helper Hint
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = if (isWristMotionActive) HeartPink else AccentBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isWristMotionActive) "손목 움직임 모드 동작 중" else "화면 드래그 = 마우스 이동\n탭 = 클릭",
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    color = if (isWristMotionActive) HeartPink else TextMuted,
                    lineHeight = 14.sp
                )
            }

            // Bottom Bar: Wrist Motion Toggle Button
            Button(
                onClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.TOGGLE_ON)
                    wristMotionDetector.toggle()
                },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(42.dp)
                    .padding(bottom = 6.dp),
                shape = RoundedCornerShape(21.dp),
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = if (isWristMotionActive) ShortsRedDark else DarkSurfaceElevated,
                    contentColor = TextWhite
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "손목 모션 토글",
                        tint = if (isWristMotionActive) Color.White else AccentBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isWristMotionActive) "손목 모션: ON" else "손목 모션: OFF",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}