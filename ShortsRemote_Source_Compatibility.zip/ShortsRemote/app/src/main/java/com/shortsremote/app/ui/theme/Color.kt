package com.shortsremote.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.wear.compose.material.Colors

val ShortsRed = Color(0xFFFF0055)
val ShortsRedDark = Color(0xFFD60046)
val HeartPink = Color(0xFFFF2A6D)
val AccentBlue = Color(0xFF38BDF8)
val DarkSurface = Color(0xFF18181B)
val DarkSurfaceElevated = Color(0xFF27272A)
val PureBlack = Color(0xFF000000)
val TextWhite = Color(0xFFF4F4F5)
val TextMuted = Color(0xFFA1A1AA)
val SuccessGreen = Color(0xFF10B981)

val WearColorPalette = Colors(
    primary = ShortsRed,
    primaryVariant = ShortsRedDark,
    secondary = AccentBlue,
    background = PureBlack,
    surface = DarkSurface,
    onPrimary = TextWhite,
    onSecondary = PureBlack,
    onBackground = TextWhite,
    onSurface = TextWhite
)